﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ClothingDeliverProject.Migrations
{
    public partial class initial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "customers",
                columns: table => new
                {
                    Customerid = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Phone = table.Column<int>(type: "int", nullable: false),
                    Address = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Password = table.Column<int>(type: "int", nullable: false),
                    Role = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_customers", x => x.Customerid);
                });

            migrationBuilder.CreateTable(
                name: "products",
                columns: table => new
                {
                    Productsid = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Price = table.Column<double>(type: "float", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_products", x => x.Productsid);
                });

            migrationBuilder.CreateTable(
                name: "order",
                columns: table => new
                {
                    Orderid = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Productsid = table.Column<int>(type: "int", nullable: false),
                    Customerid = table.Column<int>(type: "int", nullable: false),
                    Quantity = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_order", x => x.Orderid);
                    table.ForeignKey(
                        name: "FK_order_customers_Customerid",
                        column: x => x.Customerid,
                        principalTable: "customers",
                        principalColumn: "Customerid",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_order_products_Productsid",
                        column: x => x.Productsid,
                        principalTable: "products",
                        principalColumn: "Productsid",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "customers",
                columns: new[] { "Customerid", "Address", "Name", "Password", "Phone", "Role" },
                values: new object[,]
                {
                    { 1, "Tubas", "Ahmed", 1234, 598741222, "admin" },
                    { 2, "Tubas", "Ali", 2345, 568712482, "user" },
                    { 3, "Jenin", "Faries", 4567, 568741233, "user" },
                    { 4, "Jenin", "Rahma", 8523, 598741552, "user" },
                    { 5, "Tubas", "Rawan", 9632, 598741882, "user" }
                });

            migrationBuilder.InsertData(
                table: "products",
                columns: new[] { "Productsid", "Description", "Name", "Price" },
                values: new object[,]
                {
                    { 1, "Cotton, available in S/M/L", "T-Shirt", 50.0 },
                    { 2, "Blue denim, slim fit", "Jeans", 100.0 },
                    { 3, "Evening dress, red color", "Dress", 150.0 },
                    { 4, "Winter hoodie with zipper", "Hoodie", 80.0 },
                    { 5, "Running shoes, white color", "Sneakers", 120.0 }
                });

            migrationBuilder.InsertData(
                table: "order",
                columns: new[] { "Orderid", "Customerid", "Description", "Name", "Productsid", "Quantity" },
                values: new object[,]
                {
                    { 1, 2, "2 cotton T-shirts", "T-Shirt Order", 1, 2 },
                    { 2, 3, "1 slim fit jeans", "Jeans Order", 2, 1 },
                    { 3, 4, "Red evening dress", "Dress Order", 3, 1 },
                    { 4, 2, "Two pairs of sneakers", "Sneakers Order", 5, 2 }
                });

            migrationBuilder.CreateIndex(
                name: "IX_order_Customerid",
                table: "order",
                column: "Customerid");

            migrationBuilder.CreateIndex(
                name: "IX_order_Productsid",
                table: "order",
                column: "Productsid");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "order");

            migrationBuilder.DropTable(
                name: "customers");

            migrationBuilder.DropTable(
                name: "products");
        }
    }
}
