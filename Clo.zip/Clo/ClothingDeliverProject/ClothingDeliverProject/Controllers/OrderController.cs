﻿using ClothingDeliverProject.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ClothingDeliverProject.Controllers
{
    public class OrderController : Controller
    {
        private ClothingDeliverContext context { set; get; }
        public OrderController(ClothingDeliverContext c)
        {
            context = c;
        }
        public IActionResult Index()
        {
            List<Order> orders = context.order.Include(m => m.Customer).Include(s => s.Products).ToList();
            return View(orders);
        }
        public IActionResult search(int searchkey)

        {

            var prod = context.order.Where(m => m.Customerid.Equals(searchkey)).Include(m => m.Customer).Include(b => b.Products).ToList();
            return View("Index", prod);

        }
        [HttpGet]
        public IActionResult Add()
        {
            ViewBag.customers = context.customers.OrderBy(c => c.Name).ToList();
            return View();
        }
        [HttpPost]
        public IActionResult Add(Order mm)
        {
            context.order.Add(mm);
            context.SaveChanges();
            return RedirectToAction("Index");
        }
        public IActionResult Delete(int id)
        {
            Order mm = context.order.Where(m => m.Orderid == id).FirstOrDefault();
            context.Remove(mm);
            context.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
