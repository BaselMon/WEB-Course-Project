﻿using ClothingDeliverProject.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Http;
using System.Collections.Generic;
using System.Linq;


namespace ClothingDeliverProject.Controllers
{
    public class CustomerController : Controller
    {
        private ClothingDeliverContext context { set; get; }
        public CustomerController(ClothingDeliverContext c)
        {
            context = c;
        }
        public IActionResult Index()
        {
            var customer = context.customers.ToList();
            return View(customer);
        }

        [HttpGet]
    public IActionResult Add()
        {

            return View();
        }
        [HttpPost]
        public IActionResult Add(Customer cs)
        {
          Customer search = context.customers.Where(m => m.Name == cs.Name && m.Phone == cs.Phone && m.Role == cs.Role && m.Address == cs.Address).FirstOrDefault();
            if (search == null)
            {
                context.customers.Add(cs);
                context.SaveChanges();
                return RedirectToAction("Index", "Customer");
            }
            return View();
        }
        [HttpGet]
        public IActionResult login()
        { 
            if(HttpContext.Session.GetInt32("csid") == null)
            {
                return View();

            }


            return RedirectToAction("Index", "Products");
        }


        [HttpPost]
        public IActionResult login(string cuname,int cuspass)
        {
            Customer? c = context.customers.Where(m => m.Name == cuname && m.Password == cuspass).FirstOrDefault();
            if (c!=null)
            {
                HttpContext.Session.SetInt32("csid",c.Customerid);
                HttpContext.Session.SetString("csrole", c.Role);
                return RedirectToAction("Index", "Products");
            }

            return View();
        }

      
        [HttpGet]
        public IActionResult ChangePassword()
        {
            if (HttpContext.Session.GetInt32("csid") != null)
            {
                return View();
            }
            return RedirectToAction("login");
            


        }
        [HttpPost]
        public IActionResult ChangePassword(int newpass) {
            var cusid = HttpContext.Session.GetInt32("csid");
            if (cusid != null)
            {
                Customer cu = context.customers.Find(cusid);
                cu.Password= newpass;
                context.customers.Update(cu);
                context.SaveChanges();
                return RedirectToAction("Index", "Products");

            }
            return View("login");

        }
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return View("login");
        }
    }
}