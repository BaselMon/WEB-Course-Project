﻿using ClothingDeliverProject.Models;
using Microsoft.AspNetCore.Mvc;

namespace ClothingDeliverProject.Controllers
{
    public class ProductsController : Controller
    {
        private ClothingDeliverContext context { set; get; }
        public ProductsController(ClothingDeliverContext c)
        {
            context = c;
        }
        public IActionResult Index()
        { 
          var product=context.products.ToList();
            return View(product);
        }
        public IActionResult search(string searchkey)

        {

            var prod = context.products.Where(m => m.Name.Contains(searchkey)).ToList();
            return View("Index", prod);
        }
        [HttpGet]
        public IActionResult Add()
        {
            ViewBag.prod = context.products.ToList();
            return View();
        }
        [HttpPost]
        public IActionResult Add(Products mm)
        {
            context.products.Add(mm);
            context.SaveChanges();
            return RedirectToAction("Index", "Products");
        }

    }
}
