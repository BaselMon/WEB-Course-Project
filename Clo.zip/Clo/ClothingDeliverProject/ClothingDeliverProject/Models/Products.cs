﻿using ClothingDeliverProject.Models;
using System.ComponentModel.DataAnnotations;

namespace ClothingDeliverProject.Models
{
    public class Products
    {
        public int Productsid {  get; set; }

        [Required(ErrorMessage = "Please enter a Price.")]
        public double Price{ get; set; }
        [Required(ErrorMessage = "Please enter a Name.")]
        public string Name { get; set; }
        public string Description { get; set; }
    }
}
