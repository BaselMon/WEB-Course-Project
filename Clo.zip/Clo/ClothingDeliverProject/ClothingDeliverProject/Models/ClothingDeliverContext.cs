﻿using Microsoft.EntityFrameworkCore;
using System;




namespace ClothingDeliverProject.Models
{
    public class ClothingDeliverContext : DbContext
    {

        public ClothingDeliverContext(DbContextOptions<ClothingDeliverContext> option):base (option) 
        { }
        public DbSet<Customer> customers { get; set; }
        public DbSet<Products> products { get; set; }
        public DbSet<Order> order { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
           
            modelBuilder.Entity<Customer>().HasData(
                new Customer { Customerid = 1, Name = "Ahmed", Phone = 0598741222, Address = "Tubas", Password = 1234, Role = "admin" },
                new Customer { Customerid = 2, Name = "Ali",   Phone = 0568712482, Address = "Tubas", Password = 2345, Role = "user" },
                new Customer { Customerid = 3, Name = "Faries",Phone = 0568741233, Address = "Jenin", Password = 4567, Role = "user" },
                new Customer { Customerid = 4, Name = "Rahma", Phone = 0598741552, Address = "Jenin", Password = 8523, Role = "user" },
                new Customer { Customerid = 5, Name = "Rawan", Phone = 0598741882, Address = "Tubas", Password = 9632, Role = "user" }
            );

            
            modelBuilder.Entity<Products>().HasData(
                new Products { Productsid = 1,Name = "T-Shirt", Price = 50, Description = "Cotton, available in S/M/L" },
                new Products { Productsid = 2, Name = "Jeans", Price = 100, Description = "Blue denim, slim fit" },
                new Products { Productsid = 3, Name = "Dress", Price = 150, Description = "Evening dress, red color" },
                new Products { Productsid = 4, Name = "Hoodie", Price = 80, Description = "Winter hoodie with zipper" },
                new Products { Productsid = 5, Name = "Sneakers", Price = 120, Description = "Running shoes, white color" }
            );

            
            modelBuilder.Entity<Order>().HasData(
                new Order { Orderid = 1, Name = "T-Shirt Order", Description = "2 cotton T-shirts", Productsid = 1, Customerid = 2, Quantity = 2 },
                new Order { Orderid = 2, Name = "Jeans Order", Description = "1 slim fit jeans", Productsid = 2, Customerid = 3, Quantity = 1 },
                new Order { Orderid = 3, Name = "Dress Order", Description = "Red evening dress", Productsid = 3, Customerid = 4, Quantity = 1 },
                new Order { Orderid = 4, Name = "Sneakers Order", Description = "Two pairs of sneakers", Productsid = 5, Customerid = 2, Quantity = 2 }
            );
        }



    }
}
