﻿namespace ClothingDeliverProject.Models
{
    public class StringIntViewModel
    {

        public string csutomername { get; set; }
        public int customerpassword { get; set; }
    }
}
