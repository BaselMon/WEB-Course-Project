﻿using ClothingDeliverProject.Models;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.ComponentModel.DataAnnotations;

namespace ClothingDeliverProject.Models
{
    public class Order
    {
     public int Orderid { get; set; }

     [Required(ErrorMessage = "Please enter a Name.")]
     public string Name { get; set; }
     public string Description { get; set; } = null!;
     [Required(ErrorMessage = "Please enter a Proudectid.")]
        public int Productsid { get; set; }
        [ValidateNever]
        public Products Products { get; set; } = null!;
        [Required(ErrorMessage = "Please enter a Customersid .")]
        public int Customerid { get; set; } 
        [ValidateNever]
        public Customer Customer { get; set; } = null!;
      [Required(ErrorMessage = "Please enter a Quantity.")]
      [Range(1,50,ErrorMessage="Rating must be between 1 and 50")]
        public int Quantity { get; set; }
  
    }
}
