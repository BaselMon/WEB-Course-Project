﻿using System.ComponentModel.DataAnnotations;

namespace ClothingDeliverProject.Models
{
    public class Customer
    {
        
        public int Customerid { get; set; }

        [Required(ErrorMessage = "Please enter a Name.")]

        public string Name { get; set; }

        [Required(ErrorMessage = "Please enter a Phone.")]
        public int Phone { get; set; }

        [Required(ErrorMessage = "Please enter a Address.")]
        public string Address { get; set; }

        [Required(ErrorMessage = "Please enter a Password.")]
        public int Password { get; set; }

        [Required(ErrorMessage = "Please choose a role.")]
        public string Role { get; set; }


    }
}
